"""labmanager package

Provides a small CLI to list and show programs stored in the repository's
`program/` folder.
"""

__all__ = ["cli"]

__version__ = "0.1.0"
